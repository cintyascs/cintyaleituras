# Atlas de Leituras 2026–2036

Site estático pronto para GitHub Pages.

## Como publicar

1. Crie um repositório no GitHub.
2. Envie o conteúdo desta pasta para a raiz do repositório.
3. No GitHub, abra **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch principal (`main` ou `master`) e a pasta `/root`.
6. Salve e aguarde a URL pública ser gerada.

## Estrutura

- `index.html`: arquivo principal do site.

