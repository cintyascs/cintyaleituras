Estrutura do hub
- index.html -> Atlas de leitura (página principal)
- planejamento.html -> Planner de escrita
- livro-comentado.html -> Caderno comentado
- assets/favicon.svg -> ícone simples do projeto

Publique mantendo todos os arquivos juntos nesta mesma estrutura.
